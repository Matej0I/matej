# FastAPI Matej API
This is a simple FastAPI app with contact loading and saving.